import os
if os.path.exists('delicious'):
    print('it exists')
else:
    print('it does not exists')