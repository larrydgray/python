import shutil, os, os.path
os.rmdir('delicious')