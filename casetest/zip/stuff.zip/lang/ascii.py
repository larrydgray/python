# Program to find the ASCII value of the given character

# Change this value for a different result
c = 'p'

# Uncomment to take character from user
c = input("Enter a character: ")

print("The ASCII value of '" + c + "' is",ord(c))
