def hello(name):
    print('Hello '+name)
    
hello('Bob')
hello('Larry')
hello('Jane')
